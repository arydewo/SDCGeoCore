package sdc.geo.core.internal;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void convertIpStrToNum (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertIpStrToNum)>> ---
		// @sigtype java 3.5
		// [i] field:0:required strIp
		// [o] field:0:required numIp
		// pipeline
		IDataCursor idcIn = pipeline.getCursor();
			String	strIp = IDataUtil.getString( idcIn, "strIp" );
			String numIp = "";
			idcIn.destroy();
			String[] ArrStrIp = strIp.split("\\.");
			
			numIp = String.valueOf(ArrStrIp.length);
			
			String tmp2Ip = ArrStrIp[1];
			if (tmp2Ip.length() == 1) {
				tmp2Ip = "00" + tmp2Ip;
			} else if (tmp2Ip.length() == 2) {
				tmp2Ip = "0" + tmp2Ip;
			} else  {
				tmp2Ip = tmp2Ip;
			} 			
			String tmp3Ip = ArrStrIp[2];
			if (tmp3Ip.length() == 1) {
				tmp3Ip = "00" + tmp3Ip;
			} else if (tmp3Ip.length() == 2) {
				tmp3Ip = "0" + tmp3Ip;
			} else  {
				tmp3Ip = tmp3Ip;
			} 
		
			String tmp4Ip = ArrStrIp[3];
			if (tmp4Ip.length() == 1) {
				tmp4Ip = "00" + tmp4Ip;
			} else if (tmp4Ip.length() == 2) {
				tmp4Ip = "0" + tmp4Ip;
			} else  {
				tmp4Ip = tmp4Ip;
			} 
			
			numIp = ArrStrIp[0] + tmp2Ip + tmp3Ip + tmp4Ip;
		// pipeline
		IDataCursor idcOut = pipeline.getCursor();
		IDataUtil.put( idcOut, "numIp", numIp );
		idcOut.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

